# food_app

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- Check Course In Youtube (https://cutt.ly/tnDI5qi)

![1](https://user-images.githubusercontent.com/67558182/121804832-bbd31900-cc61-11eb-81d4-b0845df4f3c2.jpg) ![2](https://user-images.githubusercontent.com/67558182/121804834-bfff3680-cc61-11eb-8b02-aa2bc5918c9b.jpg)
![4](https://user-images.githubusercontent.com/67558182/121804836-c392bd80-cc61-11eb-9e7a-cb1e6ecf6a57.jpg) ![5](https://user-images.githubusercontent.com/67558182/121804840-c5f51780-cc61-11eb-8012-36d918fe8b17.jpg)
![6](https://user-images.githubusercontent.com/67558182/121804841-c7264480-cc61-11eb-8020-97d159b95cec.jpg) ![7](https://user-images.githubusercontent.com/67558182/121804842-c8f00800-cc61-11eb-9f34-e02046bb31a1.jpg)
![8](https://user-images.githubusercontent.com/67558182/121804845-cb526200-cc61-11eb-9060-3179d24c82b9.jpg) ![9](https://user-images.githubusercontent.com/67558182/121804847-cd1c2580-cc61-11eb-9842-84c33831e019.jpg)
![10](https://user-images.githubusercontent.com/67558182/121804850-cee5e900-cc61-11eb-88f0-4149fa6369a5.jpg) ![11](https://user-images.githubusercontent.com/67558182/121804851-d1484300-cc61-11eb-9b0b-aa802c1c9659.jpg)
![12](https://user-images.githubusercontent.com/67558182/121804852-d3120680-cc61-11eb-8a28-3c700c9b0af4.jpg) ![13](https://user-images.githubusercontent.com/67558182/121804855-d4dbca00-cc61-11eb-8ded-d7e12c7ce13d.jpg)
![New Project](https://user-images.githubusercontent.com/67558182/121804999-a6aaba00-cc62-11eb-8446-492f3e6f1950.jpg)


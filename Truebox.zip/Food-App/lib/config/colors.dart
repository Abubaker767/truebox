import 'package:flutter/material.dart';

Color primaryColor = Color(0xffd1ad17);
Color scaffoldBackgroundColor = Color(0xffcbcbcb);
Color textColor = Colors.black87;
